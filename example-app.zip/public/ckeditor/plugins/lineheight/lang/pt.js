CKEDITOR.plugins.setLang('lineheight','pt', {
    title: 'Altura da Linha'
} );
