CKEDITOR.plugins.setLang('lineheight','ro', {
    title: 'Înâlțimea liniei'
} );
