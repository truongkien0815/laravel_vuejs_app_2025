CKEDITOR.plugins.setLang('lineheight','pt-br', {
    title: 'Altura da Linha'
} );
