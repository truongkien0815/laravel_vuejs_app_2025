CKEDITOR.plugins.setLang('lineheight','ko', {
    title: '줄 높이'
} );
